import axios from 'axios';
import { API_BASE_URL } from '../constants/appConstants';

const api = axios.create({ baseURL: API_BASE_URL });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('kk_token');
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const productAPI = {
  getAll: () => api.get('/products'),
  getById: (id) => api.get(`/products/${id}`),
  getByCategory: (category) => api.get(`/products/category/${category}`),
  search: (q) => api.get(`/products/search?q=${encodeURIComponent(q)}`),
  getCategories: () => api.get('/products/categories'),
  create: (data) => api.post('/products', data),
  update: (id, data) => api.put(`/products/${id}`, data),
  updatePrice: (id, price) => api.patch(`/products/${id}/price`, { price }),
  updateStock: (id, stock) => api.patch(`/products/${id}/stock`, { stock }),
  delete: (id) => api.delete(`/products/${id}`),
  getAIPriceSuggestion: (id) => api.get(`/products/${id}/ai-price-suggestion`),
};

export const orderAPI = {
  create: (data) => api.post('/orders', data),
  getAll: () => api.get('/orders'),
  getToday: () => api.get('/orders/today'),
  getById: (id) => api.get(`/orders/${id}`),
  getDashboardStats: () => api.get('/orders/dashboard/stats'),
  getTopProducts: () => api.get('/orders/reports/top-products'),
  getSalesByCategory: () => api.get('/orders/reports/by-category'),
  getDailyRevenue: () => api.get('/orders/reports/daily-revenue'),
  getProfitLoss: () => api.get('/orders/reports/profit-loss'),
  getAIInsights: () => api.get('/orders/reports/ai-insights'),
};

export const customerAPI = {
  getAll: () => api.get('/customers'),
  getSummary: () => api.get('/customers/summary'),
  getLedger: (customerId) => api.get('/customers/ledger', { params: customerId ? { customerId } : {} }),
  getOrders: (customerId) => api.get(`/customers/${customerId}/orders`),
  recordPayment: (customerId, data) => api.post(`/customers/${customerId}/payments`, data),
};

export const aiAPI = {
  chat: (message) => api.post('/ai/chat', { message }),
};

export const authAPI = {
  login: (data) => api.post('/auth/login', data),
  register: (data) => api.post('/auth/register', data),
  refresh: (refreshToken) => api.post('/auth/refresh', { refreshToken }),
  me: () => api.get('/auth/me'),
  changePassword: (data) => api.post('/auth/change-password', data),
};

export const userAPI = {
  getAll: () => api.get('/users'),
  create: (data) => api.post('/users', data),
  update: (id, data) => api.put(`/users/${id}`, data),
  toggleStatus: (id) => api.patch(`/users/${id}/toggle-status`),
  delete: (id) => api.delete(`/users/${id}`),
};

export const shopAPI = {
  getAll: () => api.get('/shops'),
  create: (data) => api.post('/shops', data),
  update: (id, data) => api.put(`/shops/${id}`, data),
  toggleStatus: (id) => api.patch(`/shops/${id}/toggle-status`),
  delete: (id) => api.delete(`/shops/${id}`),
};

export default api;
