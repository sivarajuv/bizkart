import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import axios from 'axios';
import api from '../services/api';

const AuthContext = createContext(null);
const API_BASE = '/api';

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedToken = localStorage.getItem('kk_token');
    const savedUser = localStorage.getItem('kk_user');
    if (savedToken && savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setToken(savedToken);
      setUser(parsedUser);
      axios.defaults.headers.common.Authorization = `Bearer ${savedToken}`;
      api.defaults.headers.common.Authorization = `Bearer ${savedToken}`;
      if (parsedUser?.shop?.defaultLanguage) {
        localStorage.setItem('kk_language', parsedUser.shop.defaultLanguage);
      }
    }
    setLoading(false);
  }, []);

  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('kk_token');
    localStorage.removeItem('kk_user');
    delete axios.defaults.headers.common.Authorization;
    delete api.defaults.headers.common.Authorization;
  }, []);

  useEffect(() => {
    const interceptor = axios.interceptors.response.use(
      (response) => response,
      (error) => {
        const url = error.config?.url || '';
        if (error.response?.status === 401 && !url.includes('/auth/login')) {
          logout();
        }
        return Promise.reject(error);
      }
    );
    return () => axios.interceptors.response.eject(interceptor);
  }, [logout]);

  const login = async (shopCode, username, password) => {
    const response = await axios.post(`${API_BASE}/auth/login`, { shopCode, username, password });
    const { token: authToken, user: authUser } = response.data;
    setToken(authToken);
    setUser(authUser);
    localStorage.setItem('kk_token', authToken);
    localStorage.setItem('kk_user', JSON.stringify(authUser));
    axios.defaults.headers.common.Authorization = `Bearer ${authToken}`;
    api.defaults.headers.common.Authorization = `Bearer ${authToken}`;
    if (authUser?.shop?.defaultLanguage) {
      localStorage.setItem('kk_language', authUser.shop.defaultLanguage);
    }
    return authUser;
  };

  const isSuperAdmin = () => user?.role === 'SUPER_ADMIN';
  const isAdmin = () => user?.role === 'ADMIN';
  const isManager = () => user?.role === 'MANAGER';
  const isCashier = () => user?.role === 'CASHIER';
  const hasFullShopAccess = () => isSuperAdmin() || isAdmin() || isManager();
  const canManageCatalog = () => hasFullShopAccess();
  const canViewBusinessInsights = () => isAdmin() || isManager();

  return (
    <AuthContext.Provider value={{ user, token, loading, login, logout, isSuperAdmin, isAdmin, isManager, isCashier, hasFullShopAccess, canManageCatalog, canViewBusinessInsights }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
