import React, { createContext, useContext, useEffect, useState } from 'react';

const LanguageContext = createContext(null);

export const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'हिन्दी' },
  { code: 'mr', label: 'मराठी' },
  { code: 'kn', label: 'ಕನ್ನಡ' },
  { code: 'or', label: 'ଓଡ଼ିଆ' },
  { code: 'ml', label: 'മലയാളം' },
  { code: 'ta', label: 'தமிழ்' },
  { code: 'bn', label: 'বাংলা' },
  { code: 'te', label: 'తెలుగు' },
  { code: 'pa', label: 'ਪੰਜਾਬੀ' },
];

const STRINGS = {
  en: {
    dashboard: 'Dashboard',
    pointOfSale: 'Point of Sale',
    products: 'Products',
    reports: 'Reports',
    aiAssistant: 'AI Assistant',
    users: 'Users',
    shops: 'Shops',
    loginTitle: 'Welcome back',
    loginSubtitle: 'Sign in to your BizKart account',
    username: 'Username',
    password: 'Password',
    signIn: 'Sign In',
    searchProducts: 'Search products...',
    addProduct: 'Add Product',
    addUser: 'Add User',
    addShop: 'Add Shop',
    totalOrders: 'Total Orders',
    totalRevenue: 'Total Revenue',
    todayOrders: 'Today Orders',
    todayRevenue: 'Today Revenue',
    category: 'Category',
    stock: 'Stock',
    price: 'Price',
    unit: 'Unit',
    role: 'Role',
    shop: 'Business',
    signOut: 'Sign Out',
    language: 'Language',
    shopManagement: 'Business Management',
    userManagement: 'User Management',
    inventory: 'Inventory',
    configurableCatalog: 'Configurable catalog for kirana, cement, steel, and more',
  },
};

export function getLanguageLabel(code) {
  return LANGUAGES.find((item) => item.code === code)?.label || code?.toUpperCase() || 'English';
}

export function LanguageProvider({ children, preferredLanguage = 'en' }) {
  const [language, setLanguage] = useState(localStorage.getItem('kk_language') || preferredLanguage);

  useEffect(() => {
    setLanguage((current) => current || preferredLanguage || 'en');
  }, [preferredLanguage]);

  useEffect(() => {
    localStorage.setItem('kk_language', language);
  }, [language]);

  const t = (key) => STRINGS[language]?.[key] || STRINGS.en[key] || key;

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, languages: LANGUAGES }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
